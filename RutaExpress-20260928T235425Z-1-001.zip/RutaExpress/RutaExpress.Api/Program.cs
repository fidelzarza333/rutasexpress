using Microsoft.EntityFrameworkCore;
using RutaExpress.Api.Data;
using RutaExpress.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// Configuración de base de datos SQLite
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") 
    ?? "Data Source=rutaexpress.db";

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(connectionString));

// Servicios de dominio
builder.Services.AddScoped<PricingService>();

// Controladores con serialización JSON en camelCase
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
    });

// CORS permisivo para desarrollo y aplicación de escritorio
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Inicializar y sembrar la base de datos automáticamente al arrancar
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<AppDbContext>();
        DbInitializer.Initialize(context);
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "Ocurrió un error al inicializar la base de datos SQLite.");
    }
}

app.UseCors();
app.MapControllers();

// Health check sencillo
app.MapGet("/", () => Results.Ok(new
{
    sistema = "RutaExpress API",
    estado = "Online",
    version = "1.0.0-ALPHA",
    timestamp = DateTime.UtcNow
}));

app.Run();
