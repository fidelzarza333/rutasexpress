using Microsoft.EntityFrameworkCore;
using RutaExpress.Api.Models;

namespace RutaExpress.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Envio> Envíos => Set<Envio>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(u => u.Id);
            entity.HasIndex(u => u.Email).IsUnique();
            entity.Property(u => u.Email).IsRequired().HasMaxLength(150);
            entity.Property(u => u.Nombre).IsRequired().HasMaxLength(100);
            entity.Property(u => u.Apellido).IsRequired().HasMaxLength(100);
            entity.Property(u => u.Rol).IsRequired().HasMaxLength(50);
        });

        modelBuilder.Entity<Envio>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.DireccionOrigen).IsRequired().HasMaxLength(250);
            entity.Property(e => e.DireccionDestino).IsRequired().HasMaxLength(250);
            entity.Property(e => e.Estado).IsRequired().HasMaxLength(50);
            entity.Property(e => e.Precio).HasColumnType("decimal(18,2)");

            entity.HasOne(e => e.Usuario)
                  .WithMany()
                  .HasForeignKey(e => e.UsuarioId)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Repartidor)
                  .WithMany()
                  .HasForeignKey(e => e.RepartidorId)
                  .OnDelete(DeleteBehavior.SetNull);
        });
    }
}
