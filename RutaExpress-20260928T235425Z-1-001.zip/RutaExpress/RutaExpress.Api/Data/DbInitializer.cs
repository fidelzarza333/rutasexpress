using RutaExpress.Api.Models;

namespace RutaExpress.Api.Data;

public static class DbInitializer
{
    public static void Initialize(AppDbContext context)
    {
        // Asegura que la base de datos y sus tablas existan
        context.Database.EnsureCreated();

        if (context.Usuarios.Any())
        {
            return; // Ya fue sembrada
        }

        var cliente = new Usuario
        {
            Nombre = "Carlos",
            Apellido = "Gómez",
            Email = "cliente@rutaexpress.com",
            Password = "1234",
            Rol = "Cliente"
        };

        var admin = new Usuario
        {
            Nombre = "Laura",
            Apellido = "Fernández",
            Email = "admin@rutaexpress.com",
            Password = "1234",
            Rol = "Administrador"
        };

        var repartidor = new Usuario
        {
            Nombre = "Martín",
            Apellido = "Rodríguez",
            Email = "repartidor@rutaexpress.com",
            Password = "1234",
            Rol = "Repartidor"
        };

        context.Usuarios.AddRange(cliente, admin, repartidor);
        context.SaveChanges();

        // Envíos de ejemplo para pruebas inmediatas
        var envios = new List<Envio>
        {
            new Envio
            {
                UsuarioId = cliente.Id,
                RepartidorId = repartidor.Id,
                DireccionOrigen = "Av. Corrientes 1234, CABA",
                DireccionDestino = "Av. Santa Fe 3456, CABA",
                Peso = 1.5,
                Descripcion = "Documentación legal urgente",
                Distancia = 5.2,
                Precio = 3060.00m,
                Estado = "Entregado",
                FechaCreacion = DateTime.UtcNow.AddDays(-2)
            },
            new Envio
            {
                UsuarioId = cliente.Id,
                RepartidorId = repartidor.Id,
                DireccionOrigen = "Belgrano 500, San Isidro",
                DireccionDestino = "Maipú 1200, Vicente López",
                Peso = 3.0,
                Descripcion = "Caja de componentes electrónicos",
                Distancia = 10.0,
                Precio = 5000.00m, // 1500 + (300 * 10) + (1 * 500) = 5000
                Estado = "En tránsito",
                FechaCreacion = DateTime.UtcNow.AddHours(-4)
            },
            new Envio
            {
                UsuarioId = cliente.Id,
                RepartidorId = repartidor.Id,
                DireccionOrigen = "Av. Rivadavia 8900, Floresta",
                DireccionDestino = "Cabildo 2000, Belgrano",
                Peso = 4.5,
                Descripcion = "Muestra de indumentaria textil",
                Distancia = 12.0,
                Precio = 6600.00m, // 1500 + (300 * 12) + (3 * 500) = 6600
                Estado = "Pendiente",
                FechaCreacion = DateTime.UtcNow.AddMinutes(-30)
            }
        };

        context.Envíos.AddRange(envios);
        context.SaveChanges();
    }
}
