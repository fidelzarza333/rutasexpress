using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RutaExpress.Api.Data;
using RutaExpress.Api.DTOs;
using RutaExpress.Api.Models;
using RutaExpress.Api.Services;

namespace RutaExpress.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ShipmentsController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly PricingService _pricingService;

    public ShipmentsController(AppDbContext context, PricingService pricingService)
    {
        _context = context;
        _pricingService = pricingService;
    }

    [HttpPost("quote")]
    public ActionResult<QuoteResponse> CalculateQuote([FromBody] QuoteRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.DireccionOrigen) || string.IsNullOrWhiteSpace(request.DireccionDestino))
        {
            return BadRequest(new { mensaje = "Debe indicar dirección de origen y destino." });
        }

        if (request.Peso <= 0)
        {
            return BadRequest(new { mensaje = "El peso debe ser mayor a 0 kg." });
        }

        double distancia = _pricingService.EstimarDistancia(request.DireccionOrigen, request.DireccionDestino);
        decimal precio = _pricingService.CalcularPrecio(distancia, request.Peso);

        string detalle = $"Base: $1500 + Distancia ({distancia} km × $300)";
        if (request.Peso > 2.0)
        {
            double extraKg = Math.Ceiling(request.Peso - 2.0);
            detalle += $" + Exceso de peso ({extraKg} kg extra × $500)";
        }

        return Ok(new QuoteResponse
        {
            Distancia = distancia,
            Precio = precio,
            Detalle = detalle
        });
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ShipmentResponse>>> GetAll(
        [FromQuery] int? usuarioId = null,
        [FromQuery] int? repartidorId = null)
    {
        var query = _context.Envíos
            .Include(e => e.Usuario)
            .Include(e => e.Repartidor)
            .AsQueryable();

        if (usuarioId.HasValue)
        {
            query = query.Where(e => e.UsuarioId == usuarioId.Value);
        }

        if (repartidorId.HasValue)
        {
            query = query.Where(e => e.RepartidorId == repartidorId.Value);
        }

        var list = await query
            .OrderByDescending(e => e.FechaCreacion)
            .Select(e => new ShipmentResponse
            {
                Id = e.Id,
                UsuarioId = e.UsuarioId,
                ClienteNombre = e.Usuario != null ? $"{e.Usuario.Nombre} {e.Usuario.Apellido}" : "Desconocido",
                RepartidorId = e.RepartidorId,
                RepartidorNombre = e.Repartidor != null ? $"{e.Repartidor.Nombre} {e.Repartidor.Apellido}" : "Sin asignar",
                DireccionOrigen = e.DireccionOrigen,
                DireccionDestino = e.DireccionDestino,
                Peso = e.Peso,
                Descripcion = e.Descripcion,
                Distancia = e.Distancia,
                Precio = e.Precio,
                Estado = e.Estado,
                FechaCreacion = e.FechaCreacion
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ShipmentResponse>> GetById(int id)
    {
        var e = await _context.Envíos
            .Include(x => x.Usuario)
            .Include(x => x.Repartidor)
            .FirstOrDefaultAsync(x => x.Id == id);

        if (e == null)
        {
            return NotFound(new { mensaje = "Envío no encontrado." });
        }

        return Ok(new ShipmentResponse
        {
            Id = e.Id,
            UsuarioId = e.UsuarioId,
            ClienteNombre = e.Usuario != null ? $"{e.Usuario.Nombre} {e.Usuario.Apellido}" : "Desconocido",
            RepartidorId = e.RepartidorId,
            RepartidorNombre = e.Repartidor != null ? $"{e.Repartidor.Nombre} {e.Repartidor.Apellido}" : "Sin asignar",
            DireccionOrigen = e.DireccionOrigen,
            DireccionDestino = e.DireccionDestino,
            Peso = e.Peso,
            Descripcion = e.Descripcion,
            Distancia = e.Distancia,
            Precio = e.Precio,
            Estado = e.Estado,
            FechaCreacion = e.FechaCreacion
        });
    }

    [HttpPost]
    public async Task<ActionResult<ShipmentResponse>> Create([FromBody] CreateShipmentRequest request)
    {
        if (request.UsuarioId <= 0 ||
            string.IsNullOrWhiteSpace(request.DireccionOrigen) ||
            string.IsNullOrWhiteSpace(request.DireccionDestino) ||
            request.Peso <= 0)
        {
            return BadRequest(new { mensaje = "Complete todos los campos obligatorios del envío." });
        }

        var usuario = await _context.Usuarios.FindAsync(request.UsuarioId);
        if (usuario == null)
        {
            return BadRequest(new { mensaje = "Usuario remitente inválido." });
        }

        // Si no vienen calculados, calcular en backend
        double distancia = request.Distancia ?? _pricingService.EstimarDistancia(request.DireccionOrigen, request.DireccionDestino);
        decimal precio = request.Precio ?? _pricingService.CalcularPrecio(distancia, request.Peso);

        // Asignar un repartidor disponible por defecto si hay alguno en el sistema
        var repartidor = await _context.Usuarios.FirstOrDefaultAsync(u => u.Rol == "Repartidor");

        var envio = new Envio
        {
            UsuarioId = request.UsuarioId,
            RepartidorId = repartidor?.Id,
            DireccionOrigen = request.DireccionOrigen.Trim(),
            DireccionDestino = request.DireccionDestino.Trim(),
            Peso = request.Peso,
            Descripcion = string.IsNullOrWhiteSpace(request.Descripcion) ? "Paquete estándar" : request.Descripcion.Trim(),
            Distancia = distancia,
            Precio = precio,
            Estado = "Pendiente",
            FechaCreacion = DateTime.UtcNow
        };

        _context.Envíos.Add(envio);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = envio.Id }, new ShipmentResponse
        {
            Id = envio.Id,
            UsuarioId = envio.UsuarioId,
            ClienteNombre = $"{usuario.Nombre} {usuario.Apellido}",
            RepartidorId = envio.RepartidorId,
            RepartidorNombre = repartidor != null ? $"{repartidor.Nombre} {repartidor.Apellido}" : "Sin asignar",
            DireccionOrigen = envio.DireccionOrigen,
            DireccionDestino = envio.DireccionDestino,
            Peso = envio.Peso,
            Descripcion = envio.Descripcion,
            Distancia = envio.Distancia,
            Precio = envio.Precio,
            Estado = envio.Estado,
            FechaCreacion = envio.FechaCreacion
        });
    }

    [HttpPut("{id}/status")]
    public async Task<ActionResult<ShipmentResponse>> UpdateStatus(int id, [FromBody] UpdateStatusRequest request)
    {
        var envio = await _context.Envíos
            .Include(e => e.Usuario)
            .Include(e => e.Repartidor)
            .FirstOrDefaultAsync(e => e.Id == id);

        if (envio == null)
        {
            return NotFound(new { mensaje = "Envío no encontrado." });
        }

        if (!string.IsNullOrWhiteSpace(request.Estado))
        {
            envio.Estado = request.Estado.Trim();
        }

        if (request.RepartidorId.HasValue)
        {
            var repartidor = await _context.Usuarios.FindAsync(request.RepartidorId.Value);
            if (repartidor != null && repartidor.Rol == "Repartidor")
            {
                envio.RepartidorId = repartidor.Id;
                envio.Repartidor = repartidor;
            }
        }

        await _context.SaveChangesAsync();

        return Ok(new ShipmentResponse
        {
            Id = envio.Id,
            UsuarioId = envio.UsuarioId,
            ClienteNombre = envio.Usuario != null ? $"{envio.Usuario.Nombre} {envio.Usuario.Apellido}" : "Desconocido",
            RepartidorId = envio.RepartidorId,
            RepartidorNombre = envio.Repartidor != null ? $"{envio.Repartidor.Nombre} {envio.Repartidor.Apellido}" : "Sin asignar",
            DireccionOrigen = envio.DireccionOrigen,
            DireccionDestino = envio.DireccionDestino,
            Peso = envio.Peso,
            Descripcion = envio.Descripcion,
            Distancia = envio.Distancia,
            Precio = envio.Precio,
            Estado = envio.Estado,
            FechaCreacion = envio.FechaCreacion
        });
    }
}
