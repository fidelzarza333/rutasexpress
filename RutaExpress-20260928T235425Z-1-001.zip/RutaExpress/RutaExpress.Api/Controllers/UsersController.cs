using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RutaExpress.Api.Data;
using RutaExpress.Api.DTOs;

namespace RutaExpress.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _context;

    public UsersController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserResponse>>> GetAll([FromQuery] string? rol = null)
    {
        var query = _context.Usuarios.AsQueryable();

        if (!string.IsNullOrWhiteSpace(rol))
        {
            query = query.Where(u => u.Rol.ToLower() == rol.Trim().ToLower());
        }

        var users = await query
            .OrderBy(u => u.Nombre)
            .Select(u => new UserResponse
            {
                Id = u.Id,
                Nombre = u.Nombre,
                Apellido = u.Apellido,
                Email = u.Email,
                Rol = u.Rol
            })
            .ToListAsync();

        return Ok(users);
    }
}
