using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RutaExpress.Api.Data;
using RutaExpress.Api.DTOs;
using RutaExpress.Api.Models;

namespace RutaExpress.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;

    public AuthController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
        {
            return BadRequest(new { mensaje = "Complete todos los campos." });
        }

        var user = await _context.Usuarios
            .FirstOrDefaultAsync(u => u.Email.ToLower() == request.Email.Trim().ToLower());

        if (user == null || user.Password != request.Password)
        {
            return Unauthorized(new { mensaje = "Email o contraseña incorrectos." });
        }

        return Ok(new LoginResponse
        {
            Id = user.Id,
            Nombre = user.Nombre,
            Apellido = user.Apellido,
            Email = user.Email,
            Rol = user.Rol
        });
    }

    [HttpPost("register")]
    public async Task<ActionResult<LoginResponse>> Register([FromBody] RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Nombre) ||
            string.IsNullOrWhiteSpace(request.Apellido) ||
            string.IsNullOrWhiteSpace(request.Email) ||
            string.IsNullOrWhiteSpace(request.Password))
        {
            return BadRequest(new { mensaje = "Complete todos los campos obligatorios." });
        }

        var existe = await _context.Usuarios
            .AnyAsync(u => u.Email.ToLower() == request.Email.Trim().ToLower());

        if (existe)
        {
            return BadRequest(new { mensaje = "Ya existe un usuario registrado con ese email." });
        }

        var nuevo = new Usuario
        {
            Nombre = request.Nombre.Trim(),
            Apellido = request.Apellido.Trim(),
            Email = request.Email.Trim().ToLower(),
            Password = request.Password,
            Rol = string.IsNullOrWhiteSpace(request.Rol) ? "Cliente" : request.Rol.Trim()
        };

        _context.Usuarios.Add(nuevo);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(Login), new LoginResponse
        {
            Id = nuevo.Id,
            Nombre = nuevo.Nombre,
            Apellido = nuevo.Apellido,
            Email = nuevo.Email,
            Rol = nuevo.Rol
        });
    }
}
