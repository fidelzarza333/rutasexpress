namespace RutaExpress.Api.DTOs;

public class QuoteRequest
{
    public string DireccionOrigen { get; set; } = string.Empty;
    public string DireccionDestino { get; set; } = string.Empty;
    public double Peso { get; set; }
}

public class QuoteResponse
{
    public double Distancia { get; set; }
    public decimal Precio { get; set; }
    public string Detalle { get; set; } = string.Empty;
}

public class CreateShipmentRequest
{
    public int UsuarioId { get; set; }
    public string DireccionOrigen { get; set; } = string.Empty;
    public string DireccionDestino { get; set; } = string.Empty;
    public double Peso { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public double? Distancia { get; set; }
    public decimal? Precio { get; set; }
}

public class UpdateStatusRequest
{
    public string Estado { get; set; } = string.Empty; // "Pendiente", "En tránsito", "Entregado", "Cancelado"
    public int? RepartidorId { get; set; }
}

public class ShipmentResponse
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public string ClienteNombre { get; set; } = string.Empty;
    public int? RepartidorId { get; set; }
    public string RepartidorNombre { get; set; } = "Sin asignar";
    public string DireccionOrigen { get; set; } = string.Empty;
    public string DireccionDestino { get; set; } = string.Empty;
    public double Peso { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public double Distancia { get; set; }
    public decimal Precio { get; set; }
    public string Estado { get; set; } = string.Empty;
    public DateTime FechaCreacion { get; set; }
}
