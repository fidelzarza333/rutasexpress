namespace RutaExpress.Api.Models;

public class Envio
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public Usuario? Usuario { get; set; }
    public int? RepartidorId { get; set; }
    public Usuario? Repartidor { get; set; }
    public string DireccionOrigen { get; set; } = string.Empty;
    public string DireccionDestino { get; set; } = string.Empty;
    public double Peso { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public double Distancia { get; set; }
    public decimal Precio { get; set; }
    public string Estado { get; set; } = "Pendiente"; // "Pendiente", "En tránsito", "Entregado", "Cancelado"
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
}
