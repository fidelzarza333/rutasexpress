namespace RutaExpress.Api.Services;

public class PricingService
{
    private const decimal PrecioBase = 1500m;
    private const decimal CostoPorKm = 300m;
    private const decimal CostoPorKgAdicional = 500m;

    /// <summary>
    /// Simula una distancia coherente en kilómetros a partir de las direcciones
    /// </summary>
    public double EstimarDistancia(string origen, string destino)
    {
        if (string.IsNullOrWhiteSpace(origen) || string.IsNullOrWhiteSpace(destino))
        {
            return 8.0; // Distancia demo por defecto
        }

        // Cálculo determinístico para que las mismas direcciones den siempre el mismo resultado realista
        int seed = Math.Abs((origen.Trim().ToLowerInvariant() + "->" + destino.Trim().ToLowerInvariant()).GetHashCode());
        double km = 3.5 + (seed % 175) / 10.0; // Distancia entre 3.5 y 21.0 km
        return Math.Round(km, 1);
    }

    /// <summary>
    /// Calcula el precio según la fórmula oficial de RutaExpress:
    /// Base: $1500
    /// Por Km: $300
    /// Exceso de peso (> 2kg): $500 por cada kg adicional (redondeado hacia arriba)
    /// </summary>
    public decimal CalcularPrecio(double distanciaKm, double pesoKg)
    {
        decimal total = PrecioBase;

        // Costo por distancia
        total += (decimal)distanciaKm * CostoPorKm;

        // Costo por exceso de peso (> 2 kg)
        if (pesoKg > 2.0)
        {
            double kgAdicionales = Math.Ceiling(pesoKg - 2.0);
            total += (decimal)kgAdicionales * CostoPorKgAdicional;
        }

        return Math.Round(total, 2);
    }
}
