using System.Windows;
using System.Windows.Media;
using RutaExpress.Desktop.Models;
using RutaExpress.Desktop.Services;
using RutaExpress.Desktop.Views;

namespace RutaExpress.Desktop;

public partial class MainWindow : Window
{
    private readonly ApiService _apiService;
    private UsuarioDto? _currentUser;

    public MainWindow()
    {
        InitializeComponent();
        _apiService = new ApiService("http://localhost:5000");

        Loaded += async (s, e) =>
        {
            await CheckApiConnectionAsync();
            ShowLoginView();
        };
    }

    private async Task CheckApiConnectionAsync()
    {
        bool isOnline = await _apiService.CheckApiHealthAsync();
        if (isOnline)
        {
            ApiStatusDot.Fill = new SolidColorBrush(Color.FromRgb(16, 185, 129)); // Verde
            ApiStatusText.Text = "API Conectada (localhost:5000)";
            ApiStatusText.Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184));
        }
        else
        {
            ApiStatusDot.Fill = new SolidColorBrush(Color.FromRgb(239, 68, 68)); // Rojo
            ApiStatusText.Text = "API Desconectada (Inicie RutaExpress.Api)";
            ApiStatusText.Foreground = new SolidColorBrush(Color.FromRgb(248, 113, 113));
        }
    }

    private void ShowLoginView()
    {
        _currentUser = null;
        UserBadgeBorder.Visibility = Visibility.Collapsed;

        var loginView = new LoginView(_apiService);
        loginView.UserLoggedIn += OnUserLoggedIn;
        loginView.ExitRequested += () => Application.Current.Shutdown();

        MainContentHost.Content = loginView;
    }

    private void OnUserLoggedIn(UsuarioDto user)
    {
        _currentUser = user;
        
        // Actualizar barra superior
        UserBadgeBorder.Visibility = Visibility.Visible;
        UserBadgeText.Text = $"{user.NombreCompleto} ({user.Rol})";
        UserRoleEmoji.Text = user.Rol.ToLowerInvariant() switch
        {
            "administrador" => "🛡️",
            "repartidor" => "🚚",
            _ => "👤"
        };

        // Redirigir según el rol
        switch (user.Rol.Trim().ToLowerInvariant())
        {
            case "administrador":
                var adminView = new AdminView(_apiService, user);
                adminView.LogoutRequested += ShowLoginView;
                MainContentHost.Content = adminView;
                break;

            case "repartidor":
                var repartidorView = new RepartidorView(_apiService, user);
                repartidorView.LogoutRequested += ShowLoginView;
                MainContentHost.Content = repartidorView;
                break;

            case "cliente":
            default:
                var clienteView = new ClienteView(_apiService, user);
                clienteView.LogoutRequested += ShowLoginView;
                MainContentHost.Content = clienteView;
                break;
        }
    }
}