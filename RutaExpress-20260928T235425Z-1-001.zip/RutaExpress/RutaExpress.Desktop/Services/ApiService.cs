using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using RutaExpress.Desktop.Models;

namespace RutaExpress.Desktop.Services;

public class ApiService
{
    private readonly HttpClient _httpClient;
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public string BaseUrl { get; }

    public ApiService(string baseUrl = "http://localhost:5000")
    {
        BaseUrl = baseUrl.TrimEnd('/');
        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(BaseUrl),
            Timeout = TimeSpan.FromSeconds(8)
        };
    }

    public async Task<bool> CheckApiHealthAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync("/");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public async Task<(bool Success, UsuarioDto? User, string? Error)> LoginAsync(string email, string password)
    {
        try
        {
            var payload = new { Email = email, Password = password };
            var response = await _httpClient.PostAsJsonAsync("/api/auth/login", payload);

            if (response.IsSuccessStatusCode)
            {
                var user = await response.Content.ReadFromJsonAsync<UsuarioDto>(JsonOptions);
                return (true, user, null);
            }

            var error = await ParseErrorMessageAsync(response, "Email o contraseña incorrectos.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor. Asegúrese de que la API esté ejecutándose en http://localhost:5000.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error inesperado: {ex.Message}");
        }
    }

    public async Task<(bool Success, UsuarioDto? User, string? Error)> RegisterAsync(
        string nombre, string apellido, string email, string password, string rol = "Cliente")
    {
        try
        {
            var payload = new
            {
                Nombre = nombre,
                Apellido = apellido,
                Email = email,
                Password = password,
                Rol = rol
            };

            var response = await _httpClient.PostAsJsonAsync("/api/auth/register", payload);

            if (response.IsSuccessStatusCode)
            {
                var user = await response.Content.ReadFromJsonAsync<UsuarioDto>(JsonOptions);
                return (true, user, null);
            }

            var error = await ParseErrorMessageAsync(response, "No se pudo registrar el usuario.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor API.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error: {ex.Message}");
        }
    }

    public async Task<(bool Success, QuoteResultDto? Quote, string? Error)> GetQuoteAsync(
        string origen, string destino, double peso)
    {
        try
        {
            var payload = new
            {
                DireccionOrigen = origen,
                DireccionDestino = destino,
                Peso = peso
            };

            var response = await _httpClient.PostAsJsonAsync("/api/shipments/quote", payload);

            if (response.IsSuccessStatusCode)
            {
                var quote = await response.Content.ReadFromJsonAsync<QuoteResultDto>(JsonOptions);
                return (true, quote, null);
            }

            var error = await ParseErrorMessageAsync(response, "No se pudo cotizar el envío.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor API.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error: {ex.Message}");
        }
    }

    public async Task<(bool Success, EnvioDto? Shipment, string? Error)> CreateShipmentAsync(
        int usuarioId, string origen, string destino, double peso, string descripcion, double distancia, decimal precio)
    {
        try
        {
            var payload = new
            {
                UsuarioId = usuarioId,
                DireccionOrigen = origen,
                DireccionDestino = destino,
                Peso = peso,
                Descripcion = descripcion,
                Distancia = distancia,
                Precio = precio
            };

            var response = await _httpClient.PostAsJsonAsync("/api/shipments", payload);

            if (response.IsSuccessStatusCode)
            {
                var created = await response.Content.ReadFromJsonAsync<EnvioDto>(JsonOptions);
                return (true, created, null);
            }

            var error = await ParseErrorMessageAsync(response, "No se pudo guardar el envío.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor API.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error: {ex.Message}");
        }
    }

    public async Task<(bool Success, List<EnvioDto>? Shipments, string? Error)> GetShipmentsAsync(
        int? usuarioId = null, int? repartidorId = null)
    {
        try
        {
            var url = "/api/shipments?";
            if (usuarioId.HasValue) url += $"usuarioId={usuarioId.Value}&";
            if (repartidorId.HasValue) url += $"repartidorId={repartidorId.Value}&";

            var response = await _httpClient.GetAsync(url.TrimEnd('?', '&'));

            if (response.IsSuccessStatusCode)
            {
                var list = await response.Content.ReadFromJsonAsync<List<EnvioDto>>(JsonOptions);
                return (true, list ?? new List<EnvioDto>(), null);
            }

            var error = await ParseErrorMessageAsync(response, "No se pudieron obtener los envíos.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor API.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error: {ex.Message}");
        }
    }

    public async Task<(bool Success, EnvioDto? Shipment, string? Error)> UpdateShipmentStatusAsync(
        int id, string nuevoEstado, int? repartidorId = null)
    {
        try
        {
            var payload = new
            {
                Estado = nuevoEstado,
                RepartidorId = repartidorId
            };

            var response = await _httpClient.PutAsJsonAsync($"/api/shipments/{id}/status", payload);

            if (response.IsSuccessStatusCode)
            {
                var updated = await response.Content.ReadFromJsonAsync<EnvioDto>(JsonOptions);
                return (true, updated, null);
            }

            var error = await ParseErrorMessageAsync(response, "No se pudo actualizar el estado del envío.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor API.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error: {ex.Message}");
        }
    }

    public async Task<(bool Success, List<UsuarioDto>? Users, string? Error)> GetUsersAsync(string? rol = null)
    {
        try
        {
            var url = "/api/users";
            if (!string.IsNullOrWhiteSpace(rol)) url += $"?rol={Uri.EscapeDataString(rol)}";

            var response = await _httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var list = await response.Content.ReadFromJsonAsync<List<UsuarioDto>>(JsonOptions);
                return (true, list ?? new List<UsuarioDto>(), null);
            }

            var error = await ParseErrorMessageAsync(response, "No se pudieron obtener los usuarios.");
            return (false, null, error);
        }
        catch (HttpRequestException)
        {
            return (false, null, "No se pudo conectar con el servidor API.");
        }
        catch (Exception ex)
        {
            return (false, null, $"Error: {ex.Message}");
        }
    }

    private static async Task<string> ParseErrorMessageAsync(HttpResponseMessage response, string fallback)
    {
        try
        {
            var content = await response.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(content)) return fallback;

            using var doc = JsonDocument.Parse(content);
            if (doc.RootElement.TryGetProperty("mensaje", out var mensajeProp))
            {
                return mensajeProp.GetString() ?? fallback;
            }
            if (doc.RootElement.TryGetProperty("message", out var messageProp))
            {
                return messageProp.GetString() ?? fallback;
            }
            if (doc.RootElement.TryGetProperty("title", out var titleProp))
            {
                return titleProp.GetString() ?? fallback;
            }
            return fallback;
        }
        catch
        {
            return fallback;
        }
    }
}
