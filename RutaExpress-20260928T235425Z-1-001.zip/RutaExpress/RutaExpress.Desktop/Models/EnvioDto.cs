namespace RutaExpress.Desktop.Models;

public class EnvioDto
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public string ClienteNombre { get; set; } = string.Empty;
    public int? RepartidorId { get; set; }
    public string RepartidorNombre { get; set; } = "Sin asignar";
    public string DireccionOrigen { get; set; } = string.Empty;
    public string DireccionDestino { get; set; } = string.Empty;
    public double Peso { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public double Distancia { get; set; }
    public decimal Precio { get; set; }
    public string Estado { get; set; } = string.Empty;
    public DateTime FechaCreacion { get; set; }

    public string PrecioFormateado => $"${Precio:N2}";
    public string PesoFormateado => $"{Peso:0.#} kg";
    public string DistanciaFormateada => $"{Distancia:0.#} km";
    public string FechaFormateada => FechaCreacion.ToLocalTime().ToString("dd/MM/yyyy HH:mm");
}

public class QuoteResultDto
{
    public double Distancia { get; set; }
    public decimal Precio { get; set; }
    public string Detalle { get; set; } = string.Empty;

    public string PrecioFormateado => $"${Precio:N2}";
    public string DistanciaFormateada => $"{Distancia:0.#} km";
}
