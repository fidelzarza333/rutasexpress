using System.Globalization;
using System.Windows;
using RutaExpress.Desktop.Models;
using RutaExpress.Desktop.Services;

namespace RutaExpress.Desktop.Views;

public partial class NuevoEnvioDialog : Window
{
    private readonly ApiService _apiService;
    private readonly UsuarioDto _usuario;

    private double _distanciaCalculada = 0;
    private decimal _precioCalculado = 0;

    public EnvioDto? EnvioCreado { get; private set; }

    public NuevoEnvioDialog(ApiService apiService, UsuarioDto usuario)
    {
        InitializeComponent();
        _apiService = apiService;
        _usuario = usuario;
    }

    private bool TryParsePeso(out double peso)
    {
        var raw = PesoBox.Text.Trim().Replace(',', '.');
        return double.TryParse(raw, NumberStyles.Any, CultureInfo.InvariantCulture, out peso) && peso > 0;
    }

    private async void CalcularBtn_Click(object sender, RoutedEventArgs e)
    {
        HideAlert();

        var origen = OrigenBox.Text.Trim();
        var destino = DestinoBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(origen) || string.IsNullOrWhiteSpace(destino))
        {
            ShowAlert("Complete las direcciones de origen y destino.");
            return;
        }

        if (!TryParsePeso(out var peso))
        {
            ShowAlert("Ingrese un peso válido en kilogramos (ej: 2.5).");
            return;
        }

        CalcularBtn.IsEnabled = false;
        CalcularBtn.Content = "Calculando...";

        var (success, quote, error) = await _apiService.GetQuoteAsync(origen, destino, peso);

        CalcularBtn.IsEnabled = true;
        CalcularBtn.Content = "📊 Calcular envío";

        if (success && quote != null)
        {
            _distanciaCalculada = quote.Distancia;
            _precioCalculado = quote.Precio;

            DistanciaLabel.Text = quote.DistanciaFormateada;
            PrecioLabel.Text = quote.PrecioFormateado;
            DetalleLabel.Text = quote.Detalle;

            QuoteResultBorder.Visibility = Visibility.Visible;
            ConfirmarBtn.IsEnabled = true;
        }
        else
        {
            ShowAlert(error ?? "No se pudo calcular la cotización.");
        }
    }

    private async void ConfirmarBtn_Click(object sender, RoutedEventArgs e)
    {
        HideAlert();

        var origen = OrigenBox.Text.Trim();
        var destino = DestinoBox.Text.Trim();
        var descripcion = DescripcionBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(origen) || string.IsNullOrWhiteSpace(destino))
        {
            ShowAlert("Complete las direcciones de origen y destino.");
            return;
        }

        if (!TryParsePeso(out var peso))
        {
            ShowAlert("Ingrese un peso válido en kilogramos.");
            return;
        }

        ConfirmarBtn.IsEnabled = false;
        ConfirmarBtn.Content = "Guardando envío...";

        var (success, shipment, error) = await _apiService.CreateShipmentAsync(
            _usuario.Id,
            origen,
            destino,
            peso,
            descripcion,
            _distanciaCalculada,
            _precioCalculado);

        if (success && shipment != null)
        {
            EnvioCreado = shipment;
            MessageBox.Show(
                $"¡Envío #{shipment.Id} creado con éxito!\nEstado inicial: Pendiente\nPrecio: {shipment.PrecioFormateado}",
                "Envío Registrado",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            DialogResult = true;
            Close();
        }
        else
        {
            ConfirmarBtn.IsEnabled = true;
            ConfirmarBtn.Content = "✅ Confirmar envío";
            ShowAlert(error ?? "No se pudo guardar el envío.");
        }
    }

    private void CancelarBtn_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    private void ShowAlert(string message)
    {
        AlertText.Text = message;
        AlertBorder.Visibility = Visibility.Visible;
    }

    private void HideAlert()
    {
        AlertBorder.Visibility = Visibility.Collapsed;
    }
}
