using System.Windows;
using System.Windows.Controls;
using RutaExpress.Desktop.Models;
using RutaExpress.Desktop.Services;

namespace RutaExpress.Desktop.Views;

public partial class AdminView : UserControl
{
    private readonly ApiService _apiService;
    private readonly UsuarioDto _adminUser;
    private EnvioDto? _selectedShipment;

    public event Action? LogoutRequested;

    public AdminView(ApiService apiService, UsuarioDto adminUser)
    {
        InitializeComponent();
        _apiService = apiService;
        _adminUser = adminUser;

        AdminLabel.Text = $"Sesión: {_adminUser.NombreCompleto}";
        Loaded += async (s, e) => await CargarDatosAsync();
    }

    public async Task CargarDatosAsync()
    {
        // 1. Cargar Envíos
        var (shipmentsSuccess, shipments, shipmentsError) = await _apiService.GetShipmentsAsync();
        if (shipmentsSuccess && shipments != null)
        {
            AdminEnviosGrid.ItemsSource = shipments;
        }
        else
        {
            MessageBox.Show(shipmentsError ?? "Error al cargar envíos.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        // 2. Cargar Usuarios
        var (usersSuccess, users, usersError) = await _apiService.GetUsersAsync();
        if (usersSuccess && users != null)
        {
            AdminUsuariosGrid.ItemsSource = users;
        }
    }

    private void AdminEnviosGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _selectedShipment = AdminEnviosGrid.SelectedItem as EnvioDto;

        if (_selectedShipment != null)
        {
            SelectedShipmentLabel.Text = $"Envío #{_selectedShipment.Id} ({_selectedShipment.ClienteNombre}) — Estado actual: {_selectedShipment.Estado}";
            ActualizarEstadoBtn.IsEnabled = true;

            // Preseleccionar en el ComboBox
            foreach (ComboBoxItem item in EstadoComboBox.Items)
            {
                if (string.Equals(item.Content?.ToString(), _selectedShipment.Estado, StringComparison.OrdinalIgnoreCase))
                {
                    item.IsSelected = true;
                    break;
                }
            }
        }
        else
        {
            SelectedShipmentLabel.Text = "Seleccione un envío de la lista para cambiar su estado";
            ActualizarEstadoBtn.IsEnabled = false;
        }
    }

    private async void ActualizarEstado_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedShipment == null) return;

        var nuevoEstado = (EstadoComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString();
        if (string.IsNullOrWhiteSpace(nuevoEstado)) return;

        ActualizarEstadoBtn.IsEnabled = false;
        ActualizarEstadoBtn.Content = "Guardando...";

        var (success, updated, error) = await _apiService.UpdateShipmentStatusAsync(_selectedShipment.Id, nuevoEstado);

        ActualizarEstadoBtn.IsEnabled = true;
        ActualizarEstadoBtn.Content = "Guardar cambio";

        if (success && updated != null)
        {
            MessageBox.Show($"El estado del envío #{updated.Id} se actualizó a '{updated.Estado}'.", "Estado Actualizado", 
                MessageBoxButton.OK, MessageBoxImage.Information);
            await CargarDatosAsync();
        }
        else
        {
            MessageBox.Show(error ?? "No se pudo actualizar el estado.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void Actualizar_Click(object sender, RoutedEventArgs e)
    {
        await CargarDatosAsync();
    }

    private void CerrarSesion_Click(object sender, RoutedEventArgs e)
    {
        LogoutRequested?.Invoke();
    }
}
