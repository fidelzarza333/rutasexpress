using System.Windows;
using System.Windows.Controls;
using RutaExpress.Desktop.Models;
using RutaExpress.Desktop.Services;

namespace RutaExpress.Desktop.Views;

public partial class RepartidorView : UserControl
{
    private readonly ApiService _apiService;
    private readonly UsuarioDto _repartidor;
    private EnvioDto? _selectedShipment;

    public event Action? LogoutRequested;

    public RepartidorView(ApiService apiService, UsuarioDto repartidor)
    {
        InitializeComponent();
        _apiService = apiService;
        _repartidor = repartidor;

        RepartidorLabel.Text = $"Repartidor: {_repartidor.NombreCompleto}";
        Loaded += async (s, e) => await CargarEnviosAsync();
    }

    public async Task CargarEnviosAsync()
    {
        // Traer envíos asignados al repartidor (o todos si aún no fueron asignados específicamente)
        var (success, shipments, error) = await _apiService.GetShipmentsAsync(repartidorId: _repartidor.Id);

        // Si no tiene asignados específicos todavía, traer lista general para permitir tomar entregas
        if (success && (shipments == null || shipments.Count == 0))
        {
            var fallback = await _apiService.GetShipmentsAsync();
            if (fallback.Success && fallback.Shipments != null)
            {
                shipments = fallback.Shipments;
            }
        }

        if (success && shipments != null)
        {
            RepartidorGrid.ItemsSource = shipments;

            int total = shipments.Count;
            int transito = shipments.Count(x => x.Estado.Equals("En tránsito", StringComparison.OrdinalIgnoreCase));
            int entregados = shipments.Count(x => x.Estado.Equals("Entregado", StringComparison.OrdinalIgnoreCase));

            TotalAsignadosLabel.Text = total.ToString();
            EnTransitoLabel.Text = transito.ToString();
            EntregadosLabel.Text = entregados.ToString();
        }
        else
        {
            MessageBox.Show(error ?? "No se pudieron cargar los envíos de la ruta.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void RepartidorGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _selectedShipment = RepartidorGrid.SelectedItem as EnvioDto;

        if (_selectedShipment != null)
        {
            SelectedLabel.Text = $"Envío #{_selectedShipment.Id} a {_selectedShipment.DireccionDestino} — Estado: {_selectedShipment.Estado}";
            
            // Habilitar según flujo: Pendiente -> En tránsito -> Entregado
            TransitoBtn.IsEnabled = !_selectedShipment.Estado.Equals("En tránsito", StringComparison.OrdinalIgnoreCase) &&
                                    !_selectedShipment.Estado.Equals("Entregado", StringComparison.OrdinalIgnoreCase);

            EntregadoBtn.IsEnabled = !_selectedShipment.Estado.Equals("Entregado", StringComparison.OrdinalIgnoreCase);
        }
        else
        {
            SelectedLabel.Text = "Seleccione un envío para actualizar su estado de ruta:";
            TransitoBtn.IsEnabled = false;
            EntregadoBtn.IsEnabled = false;
        }
    }

    private async void TransitoBtn_Click(object sender, RoutedEventArgs e)
    {
        await CambiarEstadoAsync("En tránsito");
    }

    private async void EntregadoBtn_Click(object sender, RoutedEventArgs e)
    {
        await CambiarEstadoAsync("Entregado");
    }

    private async Task CambiarEstadoAsync(string nuevoEstado)
    {
        if (_selectedShipment == null) return;

        TransitoBtn.IsEnabled = false;
        EntregadoBtn.IsEnabled = false;

        var (success, updated, error) = await _apiService.UpdateShipmentStatusAsync(_selectedShipment.Id, nuevoEstado, _repartidor.Id);

        if (success && updated != null)
        {
            MessageBox.Show($"¡Envío #{updated.Id} actualizado a estado '{updated.Estado}'!", "Estado Actualizado", 
                MessageBoxButton.OK, MessageBoxImage.Information);
            await CargarEnviosAsync();
        }
        else
        {
            MessageBox.Show(error ?? "No se pudo actualizar el estado del envío.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            TransitoBtn.IsEnabled = true;
            EntregadoBtn.IsEnabled = true;
        }
    }

    private async void Actualizar_Click(object sender, RoutedEventArgs e)
    {
        await CargarEnviosAsync();
    }

    private void CerrarSesion_Click(object sender, RoutedEventArgs e)
    {
        LogoutRequested?.Invoke();
    }
}
