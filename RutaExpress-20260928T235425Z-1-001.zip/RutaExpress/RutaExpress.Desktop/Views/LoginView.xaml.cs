using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using RutaExpress.Desktop.Models;
using RutaExpress.Desktop.Services;

namespace RutaExpress.Desktop.Views;

public partial class LoginView : UserControl
{
    private readonly ApiService _apiService;

    public event Action<UsuarioDto>? UserLoggedIn;
    public event Action? ExitRequested;

    public LoginView(ApiService apiService)
    {
        InitializeComponent();
        _apiService = apiService;

        // Cargar por defecto el usuario cliente de prueba para agilidad
        EmailBox.Text = "cliente@rutaexpress.com";
        PasswordBox.Password = "1234";
    }

    private void TabLogin_Click(object sender, RoutedEventArgs e)
    {
        LoginFormPanel.Visibility = Visibility.Visible;
        RegisterFormPanel.Visibility = Visibility.Collapsed;
        TabLoginBtn.Background = (SolidColorBrush)FindResource("AccentBlueBrush");
        TabLoginBtn.Foreground = Brushes.White;
        TabRegisterBtn.Background = Brushes.Transparent;
        TabRegisterBtn.Foreground = (SolidColorBrush)FindResource("SecondaryGrayBrush");
        HideAlert();
    }

    private void TabRegister_Click(object sender, RoutedEventArgs e)
    {
        LoginFormPanel.Visibility = Visibility.Collapsed;
        RegisterFormPanel.Visibility = Visibility.Visible;
        TabRegisterBtn.Background = (SolidColorBrush)FindResource("AccentBlueBrush");
        TabRegisterBtn.Foreground = Brushes.White;
        TabLoginBtn.Background = Brushes.Transparent;
        TabLoginBtn.Foreground = (SolidColorBrush)FindResource("SecondaryGrayBrush");
        HideAlert();
    }

    private async void LoginBtn_Click(object sender, RoutedEventArgs e)
    {
        await PerformLogin(EmailBox.Text, PasswordBox.Password);
    }

    private async void PasswordBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            await PerformLogin(EmailBox.Text, PasswordBox.Password);
        }
    }

    private async Task PerformLogin(string email, string password)
    {
        HideAlert();

        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            ShowAlert("Complete todos los campos.");
            return;
        }

        LoginBtn.IsEnabled = false;
        LoginBtn.Content = "Iniciando sesión...";

        var (success, user, error) = await _apiService.LoginAsync(email, password);

        LoginBtn.IsEnabled = true;
        LoginBtn.Content = "Iniciar sesión";

        if (success && user != null)
        {
            UserLoggedIn?.Invoke(user);
        }
        else
        {
            ShowAlert(error ?? "Email o contraseña incorrectos.");
        }
    }

    private async void RegisterSubmitBtn_Click(object sender, RoutedEventArgs e)
    {
        HideAlert();

        var nombre = RegNombreBox.Text.Trim();
        var apellido = RegApellidoBox.Text.Trim();
        var email = RegEmailBox.Text.Trim();
        var password = RegPasswordBox.Password;

        if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellido) ||
            string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            ShowAlert("Complete todos los campos del registro.");
            return;
        }

        RegisterSubmitBtn.IsEnabled = false;
        RegisterSubmitBtn.Content = "Creando cuenta...";

        var (success, user, error) = await _apiService.RegisterAsync(nombre, apellido, email, password, "Cliente");

        RegisterSubmitBtn.IsEnabled = true;
        RegisterSubmitBtn.Content = "Crear cuenta de Cliente";

        if (success && user != null)
        {
            UserLoggedIn?.Invoke(user);
        }
        else
        {
            ShowAlert(error ?? "No se pudo registrar la cuenta.");
        }
    }

    private async void DemoCliente_Click(object sender, RoutedEventArgs e)
    {
        EmailBox.Text = "cliente@rutaexpress.com";
        PasswordBox.Password = "1234";
        await PerformLogin("cliente@rutaexpress.com", "1234");
    }

    private async void DemoAdmin_Click(object sender, RoutedEventArgs e)
    {
        EmailBox.Text = "admin@rutaexpress.com";
        PasswordBox.Password = "1234";
        await PerformLogin("admin@rutaexpress.com", "1234");
    }

    private async void DemoRepartidor_Click(object sender, RoutedEventArgs e)
    {
        EmailBox.Text = "repartidor@rutaexpress.com";
        PasswordBox.Password = "1234";
        await PerformLogin("repartidor@rutaexpress.com", "1234");
    }

    private void SalirBtn_Click(object sender, RoutedEventArgs e)
    {
        ExitRequested?.Invoke();
    }

    private void ShowAlert(string message)
    {
        AlertText.Text = message;
        AlertBorder.Visibility = Visibility.Visible;
    }

    private void HideAlert()
    {
        AlertBorder.Visibility = Visibility.Collapsed;
    }
}
