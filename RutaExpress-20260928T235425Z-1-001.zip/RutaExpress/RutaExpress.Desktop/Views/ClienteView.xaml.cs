using System.Windows;
using System.Windows.Controls;
using RutaExpress.Desktop.Models;
using RutaExpress.Desktop.Services;

namespace RutaExpress.Desktop.Views;

public partial class ClienteView : UserControl
{
    private readonly ApiService _apiService;
    private readonly UsuarioDto _usuario;

    public event Action? LogoutRequested;

    public ClienteView(ApiService apiService, UsuarioDto usuario)
    {
        InitializeComponent();
        _apiService = apiService;
        _usuario = usuario;

        WelcomeLabel.Text = $"Bienvenido/a, {_usuario.NombreCompleto}";
        Loaded += async (s, e) => await CargarEnviosAsync();
    }

    public async Task CargarEnviosAsync()
    {
        var (success, shipments, error) = await _apiService.GetShipmentsAsync(usuarioId: _usuario.Id);

        if (success && shipments != null)
        {
            EnviosGrid.ItemsSource = shipments;

            // Actualizar métricas
            int total = shipments.Count;
            int entregados = shipments.Count(x => x.Estado.Equals("Entregado", StringComparison.OrdinalIgnoreCase));
            int pendientes = shipments.Count(x => !x.Estado.Equals("Entregado", StringComparison.OrdinalIgnoreCase) && 
                                                  !x.Estado.Equals("Cancelado", StringComparison.OrdinalIgnoreCase));

            TotalEnviosLabel.Text = total.ToString();
            PendientesLabel.Text = pendientes.ToString();
            EntregadosLabel.Text = entregados.ToString();
        }
        else
        {
            MessageBox.Show(error ?? "No se pudieron obtener los envíos.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async void Actualizar_Click(object sender, RoutedEventArgs e)
    {
        await CargarEnviosAsync();
    }

    private void NuevoEnvio_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new NuevoEnvioDialog(_apiService, _usuario);
        dialog.Owner = Window.GetWindow(this);

        if (dialog.ShowDialog() == true)
        {
            // Recargar datos tras confirmar nuevo envío
            _ = CargarEnviosAsync();
        }
    }

    private void CerrarSesion_Click(object sender, RoutedEventArgs e)
    {
        LogoutRequested?.Invoke();
    }
}
