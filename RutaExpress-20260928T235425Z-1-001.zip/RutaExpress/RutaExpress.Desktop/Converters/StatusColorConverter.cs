using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace RutaExpress.Desktop.Converters;

public class StatusToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush GreenBrush = new(Color.FromRgb(16, 185, 129));   // Entregado
    private static readonly SolidColorBrush AmberBrush = new(Color.FromRgb(245, 158, 11));   // Pendiente
    private static readonly SolidColorBrush BlueBrush = new(Color.FromRgb(37, 99, 235));     // En tránsito
    private static readonly SolidColorBrush RedBrush = new(Color.FromRgb(239, 68, 68));      // Cancelado
    private static readonly SolidColorBrush GrayBrush = new(Color.FromRgb(100, 116, 139));

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is string status)
        {
            return status.ToLowerInvariant() switch
            {
                "entregado" => GreenBrush,
                "pendiente" => AmberBrush,
                "en tránsito" or "en transito" => BlueBrush,
                "cancelado" => RedBrush,
                _ => GrayBrush
            };
        }
        return GrayBrush;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}

public class StatusToBackgroundConverter : IValueConverter
{
    private static readonly SolidColorBrush GreenBg = new(Color.FromRgb(236, 253, 245));
    private static readonly SolidColorBrush AmberBg = new(Color.FromRgb(254, 243, 199));
    private static readonly SolidColorBrush BlueBg = new(Color.FromRgb(239, 246, 255));
    private static readonly SolidColorBrush RedBg = new(Color.FromRgb(254, 242, 242));
    private static readonly SolidColorBrush GrayBg = new(Color.FromRgb(241, 245, 249));

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is string status)
        {
            return status.ToLowerInvariant() switch
            {
                "entregado" => GreenBg,
                "pendiente" => AmberBg,
                "en tránsito" or "en transito" => BlueBg,
                "cancelado" => RedBg,
                _ => GrayBg
            };
        }
        return GrayBg;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
