# 🚚 RutaExpress — Versión ALPHA Funcional
> **Gestión inteligente de envíos y distribución urbana**

RutaExpress es una solución de escritorio desarrollada en **C# y .NET 8** para la gestión logística de paquetes, cálculo inteligente de fletes y seguimiento de rutas urbanas.

---

## 🏗️ Arquitectura del Sistema

El sistema implementa una arquitectura desacoplada en tres capas:

```
┌──────────────────────────────────────────────┐
│          RutaExpress.Desktop (WPF)           │
│  - Interfaz de escritorio profesional        │
│  - Vistas: Cliente, Administrador, Repartidor│
│  - ApiService (HTTP Client / JSON)           │
└──────────────────────┬───────────────────────┘
                       │ HTTP REST (puerto 5000)
                       ▼
┌──────────────────────────────────────────────┐
│        RutaExpress.Api (ASP.NET Core)        │
│  - Controladores (Auth, Shipments, Users)    │
│  - Lógica de cotización y validación         │
│  - Entity Framework Core 8                   │
└──────────────────────┬───────────────────────┘
                       │ SQLite Provider
                       ▼
┌──────────────────────────────────────────────┐
│              SQLite Database                 │
│  - rutaexpress.db (Sembrado automático)      │
└──────────────────────────────────────────────┘
```

> **Nota de Arquitectura**: La aplicación WPF no interactúa directamente con la base de datos; todas las operaciones se canalizan a través de la Web API.

---

## 🔑 Usuarios de Prueba Precargados (Demo 1-Click)

La base de datos SQLite se inicializa automáticamente en el primer arranque con los siguientes usuarios de demostración (la pantalla de inicio de WPF incluye botones de acceso rápido con 1-click):

| Rol | Correo Electrónico | Contraseña | Permisos y Vistas |
| :--- | :--- | :--- | :--- |
| **👤 Cliente** | `cliente@rutaexpress.com` | `1234` | Ver métricas, historial de envíos y cotizar/crear nuevos envíos. |
| **🛡️ Administrador** | `admin@rutaexpress.com` | `1234` | Ver todos los envíos del sistema, ver usuarios y cambiar estados. |
| **🚚 Repartidor** | `repartidor@rutaexpress.com` | `1234` | Ver envíos asignados y cambiar estados: *Pendiente* $\rightarrow$ *En tránsito* $\rightarrow$ *Entregado*. |

---

## 💵 Lógica Oficial de Cotización de Envíos

El cálculo de tarifa es ejecutado por el backend en el endpoint `POST /api/shipments/quote`:

- **Precio base:** $\$1.500$
- **Costo por kilómetro recorrido:** $\$300$
- **Recargo por exceso de peso:** Si el paquete supera los $2\text{ kg}$, se añaden $\$500$ por cada kilogramo adicional.

$$\text{Precio Total} = 1500 + (\text{Distancia en km} \times 300) + (\max(0, \text{Peso en kg} - 2) \times 500)$$

*Ejemplo*: Distancia de $10\text{ km}$ y paquete de $3\text{ kg}$:
$$1500 + (300 \times 10) + (1 \times 500) = \$5.000$$

---

## 🚀 Instrucciones para Ejecutar el Proyecto

### 1. Requisitos Previos
- [.NET 8.0 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) instalado en el equipo.
- Sistema Operativo Windows (requerido para WPF).

### 2. Iniciar el Backend (Web API)
Abra una terminal de comandos en la carpeta raíz del proyecto y ejecute:

```powershell
cd RutaExpress.Api
dotnet run --launch-profile http
```
> La API quedará escuchando en `http://localhost:5000` y creará la base de datos `rutaexpress.db` si aún no existe.

### 3. Iniciar la Aplicación de Escritorio (WPF)
En una **segunda terminal**, ejecute:

```powershell
cd RutaExpress.Desktop
dotnet run
```
> Se abrirá la ventana principal de **RutaExpress** conectada a la API.

---

## 📁 Estructura del Código

```
RutaExpress/
├── RutaExpress.sln
│
├── RutaExpress.Api/                     # Capa de Backend
│   ├── Controllers/
│   │   ├── AuthController.cs            # Login y registro de usuarios
│   │   ├── ShipmentsController.cs       # Cotizaciones, altas, consultas y estado
│   │   └── UsersController.cs           # Listado de usuarios del sistema
│   ├── Data/
│   │   ├── AppDbContext.cs              # Contexto de Entity Framework Core
│   │   └── DbInitializer.cs             # Creación y sembrado inicial de SQLite
│   ├── DTOs/                            # Contratos de transferencia de datos
│   ├── Models/
│   │   ├── Usuario.cs                   # Entidad Usuario
│   │   └── Envio.cs                     # Entidad Envío
│   ├── Services/
│   │   └── PricingService.cs            # Lógica matemática de cotización
│   ├── appsettings.json                 # Cadena de conexión Data Source=rutaexpress.db
│   └── Program.cs                       # Configuración y arranque del servidor Kestrel
│
├── RutaExpress.Desktop/                 # Capa de Presentación (WPF)
│   ├── Converters/
│   │   └── StatusColorConverter.cs      # Conversores visuales para badges de estado
│   ├── Models/                          # DTOs locales para la interfaz
│   ├── Services/
│   │   └── ApiService.cs                # Cliente HTTP para invocar la Web API
│   ├── Views/
│   │   ├── LoginView.xaml               # Pantalla de acceso y demo 1-click
│   │   ├── ClienteView.xaml             # Panel cliente (métricas, listado)
│   │   ├── NuevoEnvioDialog.xaml        # Modal con cotizador en tiempo real
│   │   ├── AdminView.xaml               # Panel administrador (envíos y usuarios)
│   │   └── RepartidorView.xaml          # Panel repartidor (avance de ruta)
│   ├── App.xaml / App.xaml.cs           # Paleta corporativa y estilos globales
│   └── MainWindow.xaml / .cs            # Ventana anfitriona y enrutador de vistas
│
└── README.md
```
